---@meta

---@source UnityEngine.AssetBundleModule.dll
---@class UnityEngine.Experimental.AssetBundlePatching.AssetBundleUtility: object
---@source UnityEngine.AssetBundleModule.dll
CS.UnityEngine.Experimental.AssetBundlePatching.AssetBundleUtility = {}

---@source UnityEngine.AssetBundleModule.dll
---@param bundles UnityEngine.AssetBundle[]
---@param filenames string[]
function CS.UnityEngine.Experimental.AssetBundlePatching.AssetBundleUtility:PatchAssetBundles(bundles, filenames) end
