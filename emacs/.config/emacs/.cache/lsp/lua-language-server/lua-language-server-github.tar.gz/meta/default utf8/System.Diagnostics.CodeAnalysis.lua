---@meta

---@source mscorlib.dll
---@class System.Diagnostics.CodeAnalysis.SuppressMessageAttribute: System.Attribute
---@source mscorlib.dll
---@field Category string
---@source mscorlib.dll
---@field CheckId string
---@source mscorlib.dll
---@field Justification string
---@source mscorlib.dll
---@field MessageId string
---@source mscorlib.dll
---@field Scope string
---@source mscorlib.dll
---@field Target string
---@source mscorlib.dll
CS.System.Diagnostics.CodeAnalysis.SuppressMessageAttribute = {}


---@source System.dll
---@class System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverageAttribute: System.Attribute
---@source System.dll
CS.System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverageAttribute = {}
