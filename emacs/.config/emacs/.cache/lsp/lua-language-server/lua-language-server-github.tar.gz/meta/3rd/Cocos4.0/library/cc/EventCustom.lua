---@meta

---@class cc.EventCustom :cc.Event
local EventCustom={ }
cc.EventCustom=EventCustom




---*  Gets event name.<br>
---* return The name of the event.
---@return string
function EventCustom:getEventName () end
---*  Constructor.<br>
---* param eventName A given name of the custom event.<br>
---* js ctor
---@param eventName string
---@return self
function EventCustom:EventCustom (eventName) end