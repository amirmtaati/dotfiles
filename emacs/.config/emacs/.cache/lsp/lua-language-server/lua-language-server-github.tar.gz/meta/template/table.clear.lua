---#if not JIT then DISABLE() end
---@meta table.clear

---@version JIT
---#DES 'table.clear'
---@param tab table
local function clear(tab) end

return clear
